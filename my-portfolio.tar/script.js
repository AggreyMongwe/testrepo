document.getElementById("recForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const newRec = document.getElementById("newRec").value.trim();
  if (newRec) {
    alert("Thank you for your recommendation! It has been received.");
    document.getElementById("newRec").value = "";
  } else {
    alert("Please write a recommendation before submitting.");
  }
});